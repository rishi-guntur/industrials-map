import { useState } from "react";
import {
  type Vertical,
  type Company,
  totalCap,
  avgPE,
  medianPE,
  fmtCap,
  fmtPE,
  segments,
  geography,
  concentration,
  countryName,
  colorFor,
} from "./lib";

type SortKey = "marketCap" | "pe" | "company";

export default function Detail({ v, idx, onClose }: { v: Vertical; idx: number; onClose: () => void }) {
  const [sort, setSort] = useState<SortKey>("marketCap");
  const [tab, setTab] = useState<"comps" | "segments" | "geo">("comps");
  const accent = colorFor(idx);

  const tot = totalCap(v);
  const wpe = avgPE(v.companies);
  const mpe = medianPE(v.companies);
  const conc = concentration(v);
  const segs = segments(v);
  const geo = geography(v);

  const sorted = [...v.companies].sort((a, b) => {
    if (sort === "company") return a.company.localeCompare(b.company);
    if (sort === "pe") return (b.pe ?? -1) - (a.pe ?? -1);
    return b.marketCap - a.marketCap;
  });

  return (
    <div className="detail" style={{ ["--ac" as string]: accent }}>
      <div className="detail-head">
        <div>
          <div className="eyebrow mono">VERTICAL DEEP-DIVE</div>
          <h2>{v.vertical}</h2>
        </div>
        <button className="close" onClick={onClose} aria-label="Close">✕</button>
      </div>

      <div className="kpis">
        <Kpi label="Sector Market Cap" value={fmtCap(tot)} />
        <Kpi label="Constituents" value={String(v.companies.length)} />
        <Kpi label="Wtd. Avg P/E" value={fmtPE(wpe)} />
        <Kpi label="Median P/E" value={fmtPE(mpe)} />
        <Kpi label="Top-Name Share" value={`${(conc.topShare * 100).toFixed(0)}%`} sub={conc.topName} />
      </div>

      <div className="tabs">
        {(["comps", "segments", "geo"] as const).map((t) => (
          <button key={t} className={tab === t ? "tab on" : "tab"} onClick={() => setTab(t)}>
            {t === "comps" ? "Comparables" : t === "segments" ? "Sub-Segments" : "Geography"}
          </button>
        ))}
      </div>

      {tab === "comps" && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th className="sortable" onClick={() => setSort("company")}>Company</th>
                <th>Segment</th>
                <th className="num sortable" onClick={() => setSort("marketCap")}>Market Cap</th>
                <th className="num sortable" onClick={() => setSort("pe")}>P/E</th>
                <th className="num">% of Sector</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c: Company) => (
                <tr key={c.company}>
                  <td>
                    <span className="cname">{c.company}</span>
                    <span className="ccountry mono">{c.country}</span>
                  </td>
                  <td className="seg">{c.classification || c.industry || "—"}</td>
                  <td className="num mono">{fmtCap(c.marketCap)}</td>
                  <td className="num mono" style={{ color: peColor(c.pe, wpe) }}>{fmtPE(c.pe)}</td>
                  <td className="num mono dim">{((c.marketCap / tot) * 100).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "segments" && (
        <div className="bars">
          {segs.map((s) => (
            <Bar key={s.name} label={s.name} value={s.cap} tot={tot} count={s.count} accent={accent} />
          ))}
        </div>
      )}

      {tab === "geo" && (
        <div className="bars">
          {geo.map((g) => (
            <Bar key={g.name} label={countryName(g.name)} value={g.cap} tot={tot} count={g.count} accent={accent} />
          ))}
        </div>
      )}
    </div>
  );
}

function peColor(pe: number | null, ref: number | null): string {
  if (pe == null || ref == null) return "var(--ink-dim)";
  if (pe > ref * 1.25) return "var(--accent-2)";
  if (pe < ref * 0.75) return "var(--pos)";
  return "var(--ink)";
}

function Kpi({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="kpi">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value mono">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function Bar({ label, value, tot, count, accent }: { label: string; value: number; tot: number; count: number; accent: string }) {
  const pct = (value / tot) * 100;
  return (
    <div className="bar-row">
      <div className="bar-top">
        <span className="bar-label">{label} <span className="dim">· {count}</span></span>
        <span className="mono bar-val">{fmtCap(value)} <span className="dim">({pct.toFixed(0)}%)</span></span>
      </div>
      <div className="bar-track">
        <div className="bar-fill" style={{ width: `${pct}%`, background: accent }} />
      </div>
    </div>
  );
}
