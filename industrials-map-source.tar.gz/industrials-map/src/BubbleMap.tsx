import { useEffect, useMemo, useRef, useState } from "react";
import * as d3 from "d3";
import { DATA, totalCap, fmtCap, colorFor, type Vertical } from "./lib";

interface Node extends d3.SimulationNodeDatum {
  v: Vertical;
  cap: number;
  r: number;
  i: number;
}

export default function BubbleMap({
  onSelect,
  selected,
}: {
  onSelect: (v: Vertical) => void;
  selected: Vertical | null;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [dims, setDims] = useState({ w: 900, h: 560 });
  const [nodes, setNodes] = useState<Node[]>([]);
  const [hover, setHover] = useState<string | null>(null);

  useEffect(() => {
    if (!wrapRef.current) return;
    const ro = new ResizeObserver((e) => {
      const r = e[0].contentRect;
      setDims({ w: r.width, h: Math.max(420, Math.min(640, r.width * 0.62)) });
    });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  const base = useMemo(() => {
    const caps = DATA.map(totalCap);
    const max = Math.max(...caps);
    const minR = Math.min(dims.w, dims.h) * 0.07;
    const maxR = Math.min(dims.w, dims.h) * 0.21;
    const rScale = d3.scaleSqrt().domain([0, max]).range([minR * 0.5, maxR]);
    return DATA.map((v, i) => ({
      v,
      cap: caps[i],
      r: Math.max(minR, rScale(caps[i])),
      i,
    })) as Node[];
  }, [dims]);

  useEffect(() => {
    const sim = d3
      .forceSimulation(base as Node[])
      .force("x", d3.forceX(dims.w / 2).strength(0.04))
      .force("y", d3.forceY(dims.h / 2).strength(0.06))
      .force("charge", d3.forceManyBody().strength(2))
      .force(
        "collide",
        d3.forceCollide<Node>().radius((d) => d.r + 6).strength(0.9)
      )
      .on("tick", () => setNodes([...(base as Node[])]));
    sim.alpha(1).restart();
    return () => void sim.stop();
  }, [base, dims]);

  return (
    <div ref={wrapRef} style={{ width: "100%" }}>
      <svg width={dims.w} height={dims.h} style={{ display: "block", overflow: "visible" }}>
        <defs>
          {DATA.map((_, i) => (
            <radialGradient id={`g${i}`} key={i} cx="35%" cy="30%" r="75%">
              <stop offset="0%" stopColor={colorFor(i)} stopOpacity={0.95} />
              <stop offset="100%" stopColor={colorFor(i)} stopOpacity={0.42} />
            </radialGradient>
          ))}
        </defs>
        {nodes.map((n) => {
          const active = selected?.vertical === n.v.vertical;
          const dim = selected && !active;
          const hov = hover === n.v.vertical;
          const label = n.v.vertical.replace(" & ", " &\n");
          return (
            <g
              key={n.v.vertical}
              transform={`translate(${n.x ?? dims.w / 2},${n.y ?? dims.h / 2})`}
              style={{ cursor: "pointer", transition: "opacity .3s" }}
              opacity={dim ? 0.28 : 1}
              onClick={() => onSelect(n.v)}
              onMouseEnter={() => setHover(n.v.vertical)}
              onMouseLeave={() => setHover(null)}
            >
              <circle
                r={n.r}
                fill={`url(#g${n.i})`}
                stroke={active || hov ? colorFor(n.i) : "rgba(255,255,255,0.12)"}
                strokeWidth={active ? 2.5 : hov ? 2 : 1}
                style={{
                  filter: active || hov ? `drop-shadow(0 0 18px ${colorFor(n.i)}66)` : "none",
                  transition: "stroke-width .2s, filter .2s",
                }}
              />
              <text
                textAnchor="middle"
                style={{ pointerEvents: "none", fontFamily: "'IBM Plex Sans',sans-serif" }}
              >
                {label.split("\n").map((ln, k, arr) => (
                  <tspan
                    key={k}
                    x={0}
                    y={-6 + (k - (arr.length - 1) / 2) * 16}
                    fontSize={Math.max(11, n.r * 0.16)}
                    fontWeight={600}
                    fill="#0a0e1a"
                  >
                    {ln.trim()}
                  </tspan>
                ))}
                <tspan
                  x={0}
                  y={n.r * 0.42}
                  fontSize={Math.max(10, n.r * 0.15)}
                  fontWeight={600}
                  fill="rgba(10,14,26,0.78)"
                  fontFamily="'IBM Plex Mono',monospace"
                >
                  {fmtCap(n.cap)}
                </tspan>
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
