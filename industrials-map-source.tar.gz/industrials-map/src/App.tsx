import { useMemo, useState } from "react";
import BubbleMap from "./BubbleMap";
import Detail from "./Detail";
import { DATA, totalCap, avgPE, fmtCap, fmtPE, type Vertical } from "./lib";
import "./app.css";

export default function App() {
  const [sel, setSel] = useState<Vertical | null>(null);
  const selIdx = sel ? DATA.findIndex((d) => d.vertical === sel.vertical) : -1;

  const stats = useMemo(() => {
    const tot = DATA.reduce((s, v) => s + totalCap(v), 0);
    const allCos = DATA.flatMap((v) => v.companies);
    const pe = avgPE(allCos);
    return { tot, count: allCos.length, pe, verticals: DATA.length };
  }, []);

  return (
    <div className="shell">
      <header className="topbar">
        <div className="brand">
          <span className="dot" />
          <div>
            <div className="brand-title">INDUSTRIALS</div>
            <div className="brand-sub mono">SECTOR MAP &middot; EQUITY UNIVERSE</div>
          </div>
        </div>
        <div className="topstats">
          <TopStat label="Aggregate Cap" value={fmtCap(stats.tot)} />
          <TopStat label="Verticals" value={String(stats.verticals)} />
          <TopStat label="Companies" value={String(stats.count)} />
          <TopStat label="Univ. Wtd P/E" value={fmtPE(stats.pe)} />
        </div>
      </header>

      <main className={sel ? "stage split" : "stage"}>
        <section className="map-panel">
          <div className="panel-head">
            <h1>Industrials Sector Map</h1>
            <p>Bubbles sized by aggregate market capitalization. Select a vertical to drill into comparables, valuation, sub-segments, and geography.</p>
          </div>
          <BubbleMap onSelect={setSel} selected={sel} />
          <div className="legend mono">CLICK A BUBBLE TO EXPAND</div>
        </section>

        {sel && (
          <section className="detail-panel">
            <Detail v={sel} idx={selIdx} onClose={() => setSel(null)} />
          </section>
        )}
      </main>

      <footer className="foot mono">
        Source: user dataset (Industrials.xlsx) &middot; P/E weighted by market cap &middot; For illustrative analysis only
      </footer>
    </div>
  );
}

function TopStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="topstat">
      <div className="ts-label">{label}</div>
      <div className="ts-value mono">{value}</div>
    </div>
  );
}
