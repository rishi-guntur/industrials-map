import raw from "./data.json";

export interface Company {
  company: string;
  marketCap: number;
  pe: number | null;
  classification: string | null;
  industry: string | null;
  country: string;
  hq: string | null;
}
export interface Vertical {
  vertical: string;
  companies: Company[];
}

export const DATA = raw as Vertical[];

// ---- formatting ----
export function fmtCap(v: number): string {
  if (v >= 1e12) return `$${(v / 1e12).toFixed(2)}T`;
  if (v >= 1e9) return `$${(v / 1e9).toFixed(1)}B`;
  if (v >= 1e6) return `$${(v / 1e6).toFixed(0)}M`;
  return `$${v.toFixed(0)}`;
}
export function fmtPE(v: number | null): string {
  return v == null ? "n/a" : `${v.toFixed(1)}x`;
}

// ---- derived metrics ----
export function totalCap(v: Vertical): number {
  return v.companies.reduce((s, c) => s + c.marketCap, 0);
}
export function avgPE(companies: Company[]): number | null {
  // market-cap-weighted P/E (the IB convention), excluding nulls
  let num = 0,
    den = 0;
  for (const c of companies) {
    if (c.pe != null) {
      num += c.pe * c.marketCap;
      den += c.marketCap;
    }
  }
  return den === 0 ? null : num / den;
}
export function medianPE(companies: Company[]): number | null {
  const xs = companies.map((c) => c.pe).filter((x): x is number => x != null).sort((a, b) => a - b);
  if (!xs.length) return null;
  const m = Math.floor(xs.length / 2);
  return xs.length % 2 ? xs[m] : (xs[m - 1] + xs[m]) / 2;
}

export interface Segment {
  name: string;
  cap: number;
  count: number;
}
export function segments(v: Vertical): Segment[] {
  const map = new Map<string, Segment>();
  for (const c of v.companies) {
    const key = c.classification || c.industry || "Other";
    const s = map.get(key) || { name: key, cap: 0, count: 0 };
    s.cap += c.marketCap;
    s.count += 1;
    map.set(key, s);
  }
  return [...map.values()].sort((a, b) => b.cap - a.cap);
}
export function geography(v: Vertical): Segment[] {
  const map = new Map<string, Segment>();
  for (const c of v.companies) {
    const s = map.get(c.country) || { name: c.country, cap: 0, count: 0 };
    s.cap += c.marketCap;
    s.count += 1;
    map.set(c.country, s);
  }
  return [...map.values()].sort((a, b) => b.cap - a.cap);
}
// Herfindahl-Hirschman concentration index (0-1), top-company share
export function concentration(v: Vertical): { hhi: number; topShare: number; topName: string } {
  const tot = totalCap(v);
  let hhi = 0;
  let top = v.companies[0];
  for (const c of v.companies) {
    const s = c.marketCap / tot;
    hhi += s * s;
    if (c.marketCap > top.marketCap) top = c;
  }
  return { hhi, topShare: top.marketCap / tot, topName: top.company };
}

const PALETTE = [
  "#54e0c7", "#6c8cff", "#f5a623", "#ff6b6b", "#3ddc84",
  "#c792ea", "#ffd166", "#4fc3f7", "#ff8a65",
];
export function colorFor(i: number): string {
  return PALETTE[i % PALETTE.length];
}

export const COUNTRY_NAMES: Record<string, string> = {
  US: "United States", GB: "United Kingdom", CA: "Canada", FR: "France",
  DE: "Germany", CH: "Switzerland", IE: "Ireland", JP: "Japan", CN: "China",
  IT: "Italy", SE: "Sweden", AU: "Australia", BR: "Brazil", LU: "Luxembourg",
  CL: "Chile", FI: "Finland", IN: "India", NL: "Netherlands",
};
export function countryName(code: string): string {
  return COUNTRY_NAMES[code] || code;
}
